"use client"
import { useState } from 'react';
import { Chat } from '../lib/types';
import Header from '@/components/Header';
import Sidebar from '@/components/Sidebar';
import ChatWindow from '@/components/ChatWindow';
import LoginPage from './login/page';

export default function Home() {
  

  return (
    <LoginPage/>
  );
}