"use client"
import { useEffect, useState } from 'react';
import Sidebar from '@/components/Sidebar';
import ChatWindow from '@/components/ChatWindow';
import { Chat } from '@/lib/types';
import { createClient } from '@/utils/supabase/client';

export default function Chatpage({ data }) {
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const supabase = createClient();

  useEffect(() => {
    // Setup Supabase authentication listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        if (event === 'SIGNED_OUT') {
          // Redirect to login if user signs out
          window.location.href = '/login';
        }
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return (
    <div className="flex flex-col h-screen">
      <div className="flex flex-row flex-1">
        <Sidebar onSelectChat={setSelectedChat} userData={data} />
        <ChatWindow chat={selectedChat} userData={data} />
      </div>
    </div>
  );
}