import { redirect } from 'next/navigation'

import { createClient } from '@/utils/supabase/server'
import Chatpage from '../chatpage/page'

export default async function PrivatePage() {
  const supabase = await createClient()
  const { data, error } = await supabase.auth.getUser()
      try{
       const { error, } = await supabase
       .from("users")
       .insert({email:data.user?.email,uid:data.user?.id});
     if (error) {
       console.log(error.message);
     }
      }catch(err){
        console.log(err,'error')
      }
  if (error || !data?.user) {
    redirect('/login')
  }

  return <Chatpage data={data} />
}