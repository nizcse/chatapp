"use client";
import { useEffect, useState } from 'react';
import { MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import { Chat, mapDbChatToChat, } from '@/lib/types';
import ChatList from './ChatList';
import { createClient } from '@/utils/supabase/client';

interface SidebarProps {
  onSelectChat: (chat: Chat) => void;
  userData: any;
}

export default function Sidebar({ onSelectChat, userData }: SidebarProps) {
  const [chats, setChats] = useState<Chat[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const supabase = createClient();

  useEffect(() => {
    const fetchChats = async () => {
      if (!userData?.user?.id) return;

      setLoading(true);
      
      // Get all chats that the user is a participant in
      const { data: participantData, error: participantError } = await supabase
        .from('chat_participants')
        .select('chat_id')
        .eq('user_id', userData.user.id);
      
      if (participantError) {
        console.error('Error fetching chat participants:', participantError);
        setLoading(false);
        return;
      }
      
      if (participantData.length === 0) {
        setLoading(false);
        return;
      }
      
      const chatIds = participantData.map(item => item.chat_id);
      
      // Fetch the actual chats
      const { data: chatData, error: chatError } = await supabase
        .from('chats')
        .select('*')
        .in('id', chatIds)
        .order('last_message_at', { ascending: false });
      
      if (chatError) {
        console.error('Error fetching chats:', chatError);
      } else {
        setChats(chatData.map(mapDbChatToChat));
      }
      
      setLoading(false);
    };

    fetchChats();

    // Set up realtime subscription for new messages (to update last_message_at)
    const subscription = supabase
      .channel('public:chats')
      .on('postgres_changes', { 
        event: 'UPDATE', 
        schema: 'public', 
        table: 'chats'
      }, () => {
        fetchChats(); // Refresh chats when any chat is updated
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [userData]);

// In your Sidebar component, modify the createNewChat function to include better error handling:

const createNewChat = async () => {
  if (!userData?.user?.id) {
    console.error('User data not available');
    return;
  }
  
  console.log('Creating new chat for user:', userData.user.id);
  
  try {
    // Create a new chat
    const { data: chatData, error: chatError } = await supabase
      .from('chats')
      .insert({
        name: `New Chat ${new Date().toLocaleTimeString()}`,
        status: 'New Conversation',
        avatar_url: 'https://picsum.photos/536/354',
      })
      .select()
      .single();
    
    if (chatError) {
      console.error('Error creating chat:', chatError);
      return;
    }
    
    console.log('Chat created successfully:', chatData);
    
    // Add the current user as participant
    const { data: participantData, error: participantError } = await supabase
      .from('chat_participants')
      .insert({
        chat_id: chatData.id,
        user_id: userData.user.id
      })
      .select();
    
    if (participantError) {
      console.error('Error adding participant:', participantError);
      return;
    }
    
    console.log('Participant added successfully:', participantData);
    
    // Select the new chat
    const newChat = mapDbChatToChat(chatData);
    setChats(prev => [newChat, ...prev]);
    onSelectChat(newChat);
  } catch (error) {
    console.error('Unexpected error:', error);
  }
};

  const filteredChats = searchQuery 
    ? chats.filter(chat => 
        chat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        chat.status.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : chats;

  return (
    <aside className="h-full flex flex-col bg-white border-r border-gray-200 w-80">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white font-semibold shadow-sm">
            P
          </div>
          <span className="ml-3 text-indigo-600 font-bold text-lg">Periskope</span>
        </div>
        
        <div className="mt-3 flex space-x-3">
          <button 
            className="px-3 py-1.5 bg-indigo-600 text-white text-sm rounded-md hover:bg-indigo-700 transition-colors"
            onClick={createNewChat}
          >
            New Chat
          </button>
          <button className="text-gray-600 text-sm hover:text-indigo-600 transition-colors duration-200">
            Filter
          </button>
        </div>
        
        <div className="mt-3 relative">
          <input
            type="text"
            placeholder="Search conversations..."
            className="w-full p-2.5 pl-10 pr-4 border border-gray-300 rounded-md text-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <MagnifyingGlassIcon className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 transform -translate-y-1/2" />
          {searchQuery && (
            <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
              Filtered
            </span>
          )}
        </div>
      </div>
      
      {loading ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      ) : chats.length === 0 ? (
        <div className="flex-1 flex items-center justify-center text-center p-4">
          <div>
            <p className="text-gray-500 mb-2">No conversations yet</p>
            <button 
              className="px-4 py-2 bg-indigo-600 text-white text-sm rounded-md hover:bg-indigo-700 transition-colors"
              onClick={createNewChat}
            >
              Start a new chat
            </button>
          </div>
        </div>
      ) : (
        <ChatList chats={filteredChats} onSelect={onSelectChat} />
      )}
    </aside>
  );
}