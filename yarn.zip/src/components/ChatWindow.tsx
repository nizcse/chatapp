"use client";
import { useEffect, useState, useRef } from 'react';
import { createClient } from '@/utils/supabase/client';
import { Chat, MessageType, mapDbMessageToMessage } from '@/lib/types';
import InputArea from './InputArea';

interface ChatWindowProps {
  chat: Chat | null;
  userData: any;
}

export default function ChatWindow({ chat, userData }: ChatWindowProps) {
  const [messages, setMessages] = useState<MessageType[]>([]);
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const supabase = createClient();

  useEffect(() => {
    if (!chat) return;

    const fetchMessages = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('chat_id', chat.id)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Error fetching messages:', error);
      } else {
        setMessages(data.map(mapDbMessageToMessage));
      }
      setLoading(false);
    };

    fetchMessages();

    // Set up realtime subscription
    const subscription = supabase
      .channel(`chat:${chat.id}`)
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'messages',
        filter: `chat_id=eq.${chat.id}`
      }, (payload) => {
        const newMessage = mapDbMessageToMessage(payload.new);
        setMessages(prev => [...prev, newMessage]);
      })
      .subscribe();

    // Mark messages as read
    const markAsRead = async () => {
      await supabase
        .from('messages')
        .update({ read: true })
        .eq('chat_id', chat.id)
        .neq('sender_id', userData?.user?.id);
    };

    markAsRead();

    return () => {
      subscription.unsubscribe();
    };
  }, [chat, userData]);

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (text: string) => {
    if (!chat || !text.trim() || !userData?.user) return;

    const newMessage = {
      chat_id: chat.id,
      sender_id: userData.user.id,
      sender_name: userData.user.email.split('@')[0], // Use username or first part of email
      content: text,
      read: false
    };

    const { error } = await supabase
      .from('messages')
      .insert(newMessage);

    if (error) {
      console.error('Error sending message:', error);
    }

    // Update last_message_at in chat
    await supabase
      .from('chats')
      .update({ last_message_at: new Date().toISOString() })
      .eq('id', chat.id);
  };

  if (!chat) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50">
        <div className="text-gray-500 text-center">
          <p className="mb-2">Select a conversation</p>
          <p className="text-sm">or start a new one</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      <div className="p-4 border-b border-gray-200 bg-white flex items-center justify-between">
        <div className="flex items-center">
          <img
            src={chat.avatar}
            alt={chat.name}
            className="w-10 h-10 rounded-full object-cover border border-gray-200"
          />
          <div className="ml-3">
            <h2 className="font-semibold text-gray-900">{chat.name}</h2>
            <p className="text-sm text-gray-500">
              {chat.active ? 'Active now' : `Last active: ${chat.timestamp}`}
            </p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
        {loading ? (
          <div className="flex justify-center py-10">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
          </div>
        ) : messages.length === 0 ? (
          <div className="text-center py-10 text-gray-500">
            <p>No messages yet</p>
            <p className="text-sm mt-1">Start the conversation!</p>
          </div>
        ) : (
          messages.map((message, index) => (
            <div
              key={message.id || index}
              className={`max-w-[70%] mb-4 ${
                message.sender_id === userData?.user?.id
                  ? 'ml-auto bg-indigo-600 text-white rounded-tl-lg rounded-tr-lg rounded-bl-lg'
                  : 'mr-auto bg-white text-gray-800 rounded-tr-lg rounded-tl-lg rounded-br-lg border border-gray-200'
              } p-3 shadow-sm`}
            >
              <p className="text-sm">{message.text}</p>
              <div
                className={`flex items-center mt-1 text-xs ${
                  message.sender_id === userData?.user?.id ? 'text-indigo-200' : 'text-gray-500'
                }`}
              >
                <span>{message.timestamp}</span>
                {message.via && (
                  <span className="ml-2">· {message.via}</span>
                )}
              </div>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      <InputArea onSendMessage={sendMessage} />
    </div>
  );
}