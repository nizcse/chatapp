import { sampleMessages, MessageType } from '../lib/types';
import Message from './Message';

export default function MessageList() {
  return (
    <div className="flex-1 p-4 overflow-y-auto bg-gray-50">
      <div className="max-w-3xl mx-auto space-y-6">
        {sampleMessages.map((message, index) => (
          <Message key={index} message={message} />
        ))}
      </div>
    </div>
  );
}
