import { Chat } from '../lib/types';
import ChatItem from './ChatItem';

interface ChatListProps {
  chats: Chat[];
  onSelect: (chat: Chat) => void;
}

export default function ChatList({ chats, onSelect }: ChatListProps) {
  return (
    <div className="flex-1 overflow-y-auto">
      <h3 className="px-4 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider bg-gray-50">
        Recent Conversations
      </h3>
      <ul className="divide-y divide-gray-200">
        {chats.map((chat) => (
          <ChatItem key={chat.id} chat={chat} onSelect={onSelect} />
        ))}
      </ul>
    </div>
  );
}
